/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        watchtower: {
          dark: '#0B1120',
          panel: '#111827',
          accent: '#3B82F6',
          accent2: '#22D3EE',
        }
      }
    },
  },
  plugins: [],
}
