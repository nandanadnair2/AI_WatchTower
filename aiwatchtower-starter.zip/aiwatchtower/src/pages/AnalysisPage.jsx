import { useNavigate } from 'react-router-dom'
import Sidebar from '../components/Sidebar.jsx'
import Topbar from '../components/Topbar.jsx'

const piiFlags = [
  { type: 'Email Address', snippet: 'r.sharma@corp.com', severity: 'Medium' },
  { type: 'Phone Number', snippet: '+91-98XXX-XX210', severity: 'Medium' },
  { type: 'Government ID', snippet: 'XXXX-XXXX-4821', severity: 'High' },
]

const policyChecks = [
  { name: 'Data Residency Policy', status: 'Passed' },
  { name: 'Confidential Source Code Policy', status: 'Passed' },
  { name: 'PII Handling Policy', status: 'Failed' },
  { name: 'Financial Disclosure Policy', status: 'Warning' },
]

const severityColor = {
  Low: 'text-emerald-400 bg-emerald-400/10',
  Medium: 'text-amber-400 bg-amber-400/10',
  High: 'text-red-400 bg-red-400/10',
}

const statusStyle = {
  Passed: 'text-emerald-400 bg-emerald-400/10',
  Warning: 'text-amber-400 bg-amber-400/10',
  Failed: 'text-red-400 bg-red-400/10',
}

const complianceScore = 62

function scoreColor(score) {
  if (score >= 80) return 'text-emerald-400'
  if (score >= 50) return 'text-amber-400'
  return 'text-red-400'
}

export default function AnalysisPage() {
  const navigate = useNavigate()

  return (
    <div className="flex bg-watchtower-dark min-h-screen">
      <Sidebar />

      <div className="flex-1 min-w-0">
        <Topbar title="Prompt Analysis" />

        <main className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-3">Submitted Prompt</h2>
              <p className="text-sm text-gray-400 bg-white/5 border border-white/10 rounded-lg p-4 leading-relaxed">
                "Draft an email to the customer including their account SSN {' '}
                <span className="text-red-400 underline decoration-red-400/50">XXXX-XXXX-4821</span> and
                contact number {' '}
                <span className="text-amber-400 underline decoration-amber-400/50">+91-98XXX-XX210</span> for
                the refund confirmation."
              </p>
            </div>

            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-3">PII Detected (via Microsoft Presidio)</h2>
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-500 border-b border-white/10">
                    <th className="py-2 font-medium">Type</th>
                    <th className="py-2 font-medium">Snippet</th>
                    <th className="py-2 font-medium">Severity</th>
                  </tr>
                </thead>
                <tbody>
                  {piiFlags.map((f, i) => (
                    <tr key={i} className="border-b border-white/5 last:border-0">
                      <td className="py-2 text-gray-300">{f.type}</td>
                      <td className="py-2 text-gray-500 font-mono text-xs">{f.snippet}</td>
                      <td className="py-2">
                        <span className={`px-2 py-1 rounded-md text-xs font-medium ${severityColor[f.severity]}`}>{f.severity}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-3">Policy Checks</h2>
              <ul className="space-y-2">
                {policyChecks.map((p, i) => (
                  <li key={i} className="flex items-center justify-between text-sm border-b border-white/5 last:border-0 pb-2 last:pb-0">
                    <span className="text-gray-400">{p.name}</span>
                    <span className={`px-2 py-1 rounded-md text-xs font-medium ${statusStyle[p.status]}`}>{p.status}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-6 text-center">
              <p className="text-sm text-gray-400 mb-2">Compliance Score</p>
              <p className={`text-5xl font-bold ${scoreColor(complianceScore)}`}>{complianceScore}</p>
              <p className="text-xs text-gray-500 mt-2">out of 100</p>
              <div className="w-full h-2 bg-white/10 rounded-full mt-4 overflow-hidden">
                <div
                  className={`h-full rounded-full ${complianceScore >= 80 ? 'bg-emerald-400' : complianceScore >= 50 ? 'bg-amber-400' : 'bg-red-400'}`}
                  style={{ width: `${complianceScore}%` }}
                />
              </div>
            </div>

            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-2">Recommendation</h2>
              <p className="text-sm text-gray-400 leading-relaxed">
                Government ID detected. This prompt requires masking or manual approval
                before being sent to the model. Route to Approval Queue.
              </p>
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={() => navigate('/approval')}
                className="w-full rounded-lg bg-gradient-to-r from-watchtower-accent to-watchtower-accent2 text-white text-sm font-medium py-2.5 hover:opacity-90 transition"
              >
                Send to Approval Queue
              </button>
              <button
                onClick={() => navigate('/prompt')}
                className="w-full rounded-lg border border-white/10 text-gray-300 text-sm font-medium py-2.5 hover:bg-white/5 transition"
              >
                Edit Prompt
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
