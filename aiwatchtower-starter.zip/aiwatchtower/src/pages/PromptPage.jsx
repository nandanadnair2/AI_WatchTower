import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Sidebar from '../components/Sidebar.jsx'
import Topbar from '../components/Topbar.jsx'

const recentSubmissions = [
  { id: 1, prompt: 'Summarize Q3 financials for board deck presentation', time: '2 min ago' },
  { id: 2, prompt: 'Generate Python script to parse internal API logs', time: '18 min ago' },
  { id: 3, prompt: 'Draft customer support reply for refund request', time: '1 hr ago' },
]

const models = ['GPT-4o', 'Gemini 1.5 Pro', 'Claude', 'Internal LLM']

export default function PromptPage() {
  const navigate = useNavigate()
  const [prompt, setPrompt] = useState('')
  const [model, setModel] = useState(models[0])
  const [submitting, setSubmitting] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    if (!prompt.trim()) return

    setSubmitting(true)
    // TODO: replace with real call to FastAPI endpoint that forwards to
    // Member 3's compliance engine (Presidio PII scan + policy check) before
    // hitting the actual model API.
    setTimeout(() => {
      setSubmitting(false)
      navigate('/analysis')
    }, 700)
  }

  return (
    <div className="flex bg-watchtower-dark min-h-screen">
      <Sidebar />

      <div className="flex-1 min-w-0">
        <Topbar title="AI Prompt" />

        <main className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-medium">New Prompt</h2>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="bg-white/5 border border-white/10 text-sm text-gray-300 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-watchtower-accent"
                >
                  {models.map((m) => (
                    <option key={m} value={m} className="bg-watchtower-panel">{m}</option>
                  ))}
                </select>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Type or paste the prompt you want to send to the AI model…"
                  rows={8}
                  className="w-full rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 px-4 py-3 resize-none focus:outline-none focus:ring-2 focus:ring-watchtower-accent"
                />

                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-500">
                    Prompts are scanned for PII and policy violations before reaching the model.
                  </p>
                  <button
                    type="submit"
                    disabled={submitting || !prompt.trim()}
                    className="rounded-lg bg-gradient-to-r from-watchtower-accent to-watchtower-accent2 text-white text-sm font-medium px-5 py-2.5 hover:opacity-90 transition disabled:opacity-50"
                  >
                    {submitting ? 'Analyzing…' : 'Submit for Analysis'}
                  </button>
                </div>
              </form>
            </div>

            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-3">Your Recent Prompts</h2>
              <ul className="space-y-2">
                {recentSubmissions.map((item) => (
                  <li key={item.id} className="flex items-center justify-between text-sm border-b border-white/5 last:border-0 pb-2 last:pb-0">
                    <span className="text-gray-400 truncate pr-4">{item.prompt}</span>
                    <span className="text-gray-600 shrink-0">{item.time}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-3">Pre-Submission Checklist</h2>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> No customer PII included
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> No confidential source code
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> Financial data flagged for review
                </li>
              </ul>
            </div>

            <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
              <h2 className="text-white font-medium mb-2">How This Works</h2>
              <p className="text-sm text-gray-400 leading-relaxed">
                Every prompt is intercepted before reaching {model}, scanned by our compliance
                engine for PII and policy risk, then routed to the Analysis screen with a
                risk score and recommendation.
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
