import Sidebar from '../components/Sidebar.jsx'
import Topbar from '../components/Topbar.jsx'
import StatCard from '../components/StatCard.jsx'

const recentPrompts = [
  { id: 1, user: 'r.sharma@corp.com', prompt: 'Summarize Q3 financials for board deck…', risk: 'Low', status: 'Approved' },
  { id: 2, user: 'a.mehta@corp.com', prompt: 'Draft email including customer SSNs for…', risk: 'High', status: 'Blocked' },
  { id: 3, user: 'k.iyer@corp.com', prompt: 'Generate code to parse internal API logs…', risk: 'Medium', status: 'Pending' },
  { id: 4, user: 'p.nair@corp.com', prompt: 'Rewrite marketing copy for landing page…', risk: 'Low', status: 'Approved' },
]

const riskColor = {
  Low: 'text-emerald-400 bg-emerald-400/10',
  Medium: 'text-amber-400 bg-amber-400/10',
  High: 'text-red-400 bg-red-400/10',
}

const statusColor = {
  Approved: 'text-emerald-400 bg-emerald-400/10',
  Blocked: 'text-red-400 bg-red-400/10',
  Pending: 'text-gray-300 bg-white/10',
}

export default function Dashboard() {
  return (
    <div className="flex bg-watchtower-dark min-h-screen">
      <Sidebar />

      <div className="flex-1 min-w-0">
        <Topbar title="Dashboard" />

        <main className="p-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Prompts Monitored Today" value="1,284" delta="12%" />
            <StatCard label="PII Flags Detected" value="37" delta="4%" deltaPositive={false} />
            <StatCard label="Avg. Compliance Score" value="91.4" delta="2.1%" />
            <StatCard label="Pending Approvals" value="9" />
          </div>

          <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/10">
              <h2 className="text-white font-medium">Recent Prompt Activity</h2>
              <p className="text-sm text-gray-500">Live feed from the compliance engine</p>
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b border-white/10">
                  <th className="px-5 py-3 font-medium">User</th>
                  <th className="px-5 py-3 font-medium">Prompt</th>
                  <th className="px-5 py-3 font-medium">Risk</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentPrompts.map((row) => (
                  <tr key={row.id} className="border-b border-white/5 last:border-0">
                    <td className="px-5 py-3 text-gray-300">{row.user}</td>
                    <td className="px-5 py-3 text-gray-400 max-w-xs truncate">{row.prompt}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2 py-1 rounded-md text-xs font-medium ${riskColor[row.risk]}`}>{row.risk}</span>
                    </td>
                    <td className="px-5 py-3">
                      <span className={`px-2 py-1 rounded-md text-xs font-medium ${statusColor[row.status]}`}>{row.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  )
}
