export default function Topbar({ title }) {
  return (
    <header className="h-16 flex items-center justify-between px-6 border-b border-white/10 bg-watchtower-dark/60 backdrop-blur">
      <h1 className="text-lg font-semibold text-white">{title}</h1>

      <div className="flex items-center gap-4">
        <button className="relative text-gray-400 hover:text-white transition">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-watchtower-accent2" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-watchtower-accent to-watchtower-accent2 flex items-center justify-center text-xs font-semibold text-white">
            M1
          </div>
          <span className="text-sm text-gray-300">Member 1</span>
        </div>
      </div>
    </header>
  )
}
