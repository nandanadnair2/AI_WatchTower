export default function StatCard({ label, value, delta, deltaPositive = true }) {
  return (
    <div className="bg-watchtower-panel/70 border border-white/10 rounded-xl p-5">
      <p className="text-sm text-gray-400">{label}</p>
      <div className="flex items-end justify-between mt-2">
        <span className="text-2xl font-semibold text-white">{value}</span>
        {delta && (
          <span className={`text-xs font-medium ${deltaPositive ? 'text-emerald-400' : 'text-red-400'}`}>
            {deltaPositive ? '▲' : '▼'} {delta}
          </span>
        )}
      </div>
    </div>
  )
}
