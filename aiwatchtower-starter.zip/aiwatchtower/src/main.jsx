import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import PromptPage from './pages/PromptPage.jsx'
import AnalysisPage from './pages/AnalysisPage.jsx'
import './index.css'

// Remaining pages will be added here as we build them
function Placeholder({ name }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-watchtower-dark text-gray-300">
      <p>{name} — coming soon</p>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/prompt" element={<PromptPage />} />
        <Route path="/analysis" element={<AnalysisPage />} />
        <Route path="/response" element={<Placeholder name="AI Response" />} />
        <Route path="/approval" element={<Placeholder name="Approval Queue" />} />
        <Route path="/analytics" element={<Placeholder name="Analytics" />} />
        <Route path="/reports" element={<Placeholder name="Reports" />} />
        <Route path="/policy" element={<Placeholder name="Policy Management" />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
)
